$(document).ready(function()
{ 
       $(document).bind("contextmenu",function(e){
              return false;
       }); 
})