// var fb = window.open('http://127.0.0.1:8081');
// if(fb) {
//     fb.onload = function() {
//         fb.document.getElementById('user_name').value = 'dgresano';
//         fb.document.getElementById('password_hash').value = '1';
      
//     }
// } else {
//     alert('Please allow popups for this website');
// }