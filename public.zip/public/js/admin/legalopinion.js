(function($){

    "use strict";

    //active
    $('#legalopinion').addClass('active');

    $('#users_roles_link').addClass('active');
    $('#users_roles').addClass('menu-open');
    //files datatable
    


})(jQuery);

